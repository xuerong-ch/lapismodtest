﻿$ErrorActionPreference = 'Stop'

# MSIX/App Installer validates self-signed package certificates against the
# Local Computer trust stores. Elevate once so we can install the public
# certificate into LocalMachine\TrustedPeople.
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host 'Se necesitan permisos de administrador para confiar el certificado de desarrollo. Solicitando elevación...'
    $args = @(
        '-NoProfile',
        '-ExecutionPolicy', 'Bypass',
        '-File', ('"{0}"' -f $PSCommandPath)
    )
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $args
    exit
}

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$External = Join-Path $Root 'external'
$Msix = Join-Path $Root 'SevenZipModernContext.identity.msix'
$Cer = Join-Path $Root 'SevenZipModernContext.cer'

if (-not (Test-Path $Msix)) { throw "No se encuentra $Msix" }
if (-not (Test-Path $Cer)) { throw "No se encuentra $Cer" }
if (-not (Test-Path (Join-Path $External 'SevenZipModernContext.dll'))) { throw 'Falta la DLL en external\' }

Write-Host 'Instalando certificado de desarrollo en LocalMachine\\TrustedPeople...'
Import-Certificate -FilePath $Cer -CertStoreLocation 'Cert:\LocalMachine\TrustedPeople' | Out-Null

Get-AppxPackage -Name 'SevenZip.ModernContext' -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Host "Quitando versión anterior: $($_.PackageFullName)"
    Remove-AppxPackage -Package $_.PackageFullName
}

Write-Host 'Registrando paquete sparse...'
Add-AppxPackage -Path $Msix -ExternalLocation (Resolve-Path $External)

Write-Host 'Reiniciando Explorer para recargar el menú contextual...'
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 800
Start-Process explorer.exe

Write-Host ''
Write-Host 'Listo. Prueba botón derecho sobre un .7z/.zip/.rar y busca "Extraer aquí" en el menú moderno.' -ForegroundColor Green
