$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$External = Join-Path $Root 'external'
$Msix = Join-Path $Root 'SevenZipModernContext.identity.msix'
$Cer = Join-Path $Root 'SevenZipModernContext.cer'

if (-not (Test-Path $Msix)) { throw "No se encuentra $Msix" }
if (-not (Test-Path $Cer)) { throw "No se encuentra $Cer" }
if (-not (Test-Path (Join-Path $External 'SevenZipModernContext.dll'))) { throw 'Falta la DLL en external\' }

Write-Host 'Instalando certificado de desarrollo en CurrentUser\\TrustedPeople...'
Import-Certificate -FilePath $Cer -CertStoreLocation 'Cert:\CurrentUser\TrustedPeople' | Out-Null

Get-AppxPackage -Name 'SevenZip.ModernContext' -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Host "Quitando versión anterior: $($_.PackageFullName)"
    Remove-AppxPackage -Package $_.PackageFullName
}

Write-Host 'Registrando paquete sparse...'
Add-AppxPackage -Path $Msix -ExternalLocation (Resolve-Path $External)

Write-Host 'Reiniciando Explorer para recargar el menú contextual...'
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 800
Start-Process explorer.exe

Write-Host ''
Write-Host 'Listo. Prueba botón derecho sobre un .7z/.zip/.rar y busca "Extraer aquí" en el menú moderno.' -ForegroundColor Green
