$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Cer = Join-Path $Root 'SevenZipModernContext.cer'

Get-AppxPackage -Name 'SevenZip.ModernContext' -ErrorAction SilentlyContinue | ForEach-Object {
    Write-Host "Eliminando $($_.PackageFullName)"
    Remove-AppxPackage -Package $_.PackageFullName
}

if (Test-Path $Cer) {
    $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2($Cer)
    $installed = Get-ChildItem 'Cert:\CurrentUser\TrustedPeople' | Where-Object Thumbprint -eq $cert.Thumbprint
    if ($installed) {
        $installed | Remove-Item -Force
        Write-Host 'Certificado de desarrollo eliminado.'
    }
}

Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 800
Start-Process explorer.exe
Write-Host 'Desinstalado.' -ForegroundColor Green
