#include <windows.h>
#include <shobjidl_core.h>
#include <shellapi.h>
#include <shlwapi.h>
#include <atomic>
#include <filesystem>
#include <string>
#include <array>
#include <algorithm>
#include <cwctype>

namespace {

// {7B50C91D-61B1-4F44-B5A9-D62A86F11372}
constexpr CLSID CLSID_ExtractHere =
{0x7b50c91d, 0x61b1, 0x4f44, {0xb5, 0xa9, 0xd6, 0x2a, 0x86, 0xf1, 0x13, 0x72}};

std::atomic<long> g_objectCount{0};
std::atomic<long> g_lockCount{0};

constexpr std::array<const wchar_t*, 18> kArchiveExtensions = {
    L".7z", L".zip", L".rar", L".tar", L".gz", L".tgz",
    L".bz2", L".tbz2", L".xz", L".txz", L".zst", L".tzst",
    L".cab", L".iso", L".wim", L".arj", L".lzh", L".lha"
};

HRESULT CopyCoTaskMemString(const wchar_t* value, PWSTR* out) {
    if (!out) return E_POINTER;
    *out = nullptr;
    if (!value) return S_OK;

    const size_t bytes = (wcslen(value) + 1) * sizeof(wchar_t);
    auto* buffer = static_cast<PWSTR>(CoTaskMemAlloc(bytes));
    if (!buffer) return E_OUTOFMEMORY;
    memcpy(buffer, value, bytes);
    *out = buffer;
    return S_OK;
}

std::wstring ToLower(std::wstring value) {
    std::transform(value.begin(), value.end(), value.begin(),
        [](wchar_t ch) { return static_cast<wchar_t>(std::towlower(ch)); });
    return value;
}

bool IsSupportedArchive(const std::filesystem::path& path) {
    const auto ext = ToLower(path.extension().wstring());
    return std::any_of(kArchiveExtensions.begin(), kArchiveExtensions.end(),
        [&](const wchar_t* candidate) { return ext == candidate; });
}

std::wstring ReadRegistryString(HKEY root, const wchar_t* subKey, const wchar_t* valueName, REGSAM viewFlags) {
    HKEY key = nullptr;
    if (RegOpenKeyExW(root, subKey, 0, KEY_READ | viewFlags, &key) != ERROR_SUCCESS) {
        return {};
    }

    DWORD type = 0;
    DWORD bytes = 0;
    if (RegQueryValueExW(key, valueName, nullptr, &type, nullptr, &bytes) != ERROR_SUCCESS ||
        (type != REG_SZ && type != REG_EXPAND_SZ) || bytes == 0) {
        RegCloseKey(key);
        return {};
    }

    std::wstring value(bytes / sizeof(wchar_t), L'\0');
    if (RegQueryValueExW(key, valueName, nullptr, &type,
        reinterpret_cast<LPBYTE>(value.data()), &bytes) != ERROR_SUCCESS) {
        RegCloseKey(key);
        return {};
    }
    RegCloseKey(key);

    while (!value.empty() && value.back() == L'\0') value.pop_back();

    if (type == REG_EXPAND_SZ) {
        DWORD needed = ExpandEnvironmentStringsW(value.c_str(), nullptr, 0);
        if (needed > 0) {
            std::wstring expanded(needed, L'\0');
            if (ExpandEnvironmentStringsW(value.c_str(), expanded.data(), needed) > 0) {
                while (!expanded.empty() && expanded.back() == L'\0') expanded.pop_back();
                value = std::move(expanded);
            }
        }
    }
    return value;
}

std::filesystem::path FindSevenZipGui() {
    constexpr const wchar_t* kKey = L"SOFTWARE\\7-Zip";

    for (HKEY root : {HKEY_CURRENT_USER, HKEY_LOCAL_MACHINE}) {
        for (REGSAM view : {static_cast<REGSAM>(KEY_WOW64_64KEY), static_cast<REGSAM>(KEY_WOW64_32KEY), static_cast<REGSAM>(0)}) {
            auto base = ReadRegistryString(root, kKey, L"Path", view);
            if (!base.empty()) {
                std::filesystem::path exe = std::filesystem::path(base) / L"7zG.exe";
                std::error_code ec;
                if (std::filesystem::is_regular_file(exe, ec)) return exe;
            }
        }
    }

    wchar_t programFiles[MAX_PATH]{};
    DWORD size = GetEnvironmentVariableW(L"ProgramFiles", programFiles, MAX_PATH);
    if (size > 0 && size < MAX_PATH) {
        auto exe = std::filesystem::path(programFiles) / L"7-Zip" / L"7zG.exe";
        std::error_code ec;
        if (std::filesystem::is_regular_file(exe, ec)) return exe;
    }

    return {};
}

HRESULT GetSingleFilePath(IShellItemArray* items, std::filesystem::path& path) {
    if (!items) return E_INVALIDARG;

    DWORD count = 0;
    HRESULT hr = items->GetCount(&count);
    if (FAILED(hr) || count != 1) return E_INVALIDARG;

    IShellItem* item = nullptr;
    hr = items->GetItemAt(0, &item);
    if (FAILED(hr)) return hr;

    PWSTR rawPath = nullptr;
    hr = item->GetDisplayName(SIGDN_FILESYSPATH, &rawPath);
    item->Release();
    if (FAILED(hr)) return hr;

    path = rawPath;
    CoTaskMemFree(rawPath);
    return S_OK;
}

std::wstring Quote(const std::wstring& value) {
    std::wstring result;
    result.reserve(value.size() + 2);
    result.push_back(L'"');
    for (wchar_t ch : value) {
        if (ch == L'"') result.push_back(L'\\');
        result.push_back(ch);
    }
    result.push_back(L'"');
    return result;
}

class ExtractHereCommand final : public IExplorerCommand {
public:
    ExtractHereCommand() { ++g_objectCount; }
    ~ExtractHereCommand() { --g_objectCount; }

    IFACEMETHODIMP QueryInterface(REFIID riid, void** ppv) override {
        if (!ppv) return E_POINTER;
        *ppv = nullptr;
        if (riid == IID_IUnknown || riid == __uuidof(IExplorerCommand)) {
            *ppv = static_cast<IExplorerCommand*>(this);
            AddRef();
            return S_OK;
        }
        return E_NOINTERFACE;
    }

    IFACEMETHODIMP_(ULONG) AddRef() override {
        return ++refCount_;
    }

    IFACEMETHODIMP_(ULONG) Release() override {
        ULONG value = --refCount_;
        if (value == 0) delete this;
        return value;
    }

    IFACEMETHODIMP GetTitle(IShellItemArray*, PWSTR* name) override {
        return CopyCoTaskMemString(L"Extraer aquí", name);
    }

    IFACEMETHODIMP GetIcon(IShellItemArray*, PWSTR* icon) override {
        if (!icon) return E_POINTER;
        *icon = nullptr;
        const auto sevenZip = FindSevenZipGui();
        if (sevenZip.empty()) return S_FALSE;
        return CopyCoTaskMemString(sevenZip.c_str(), icon);
    }

    IFACEMETHODIMP GetToolTip(IShellItemArray*, PWSTR* tip) override {
        return CopyCoTaskMemString(L"Extraer este archivo en la carpeta actual con 7-Zip", tip);
    }

    IFACEMETHODIMP GetCanonicalName(GUID* guidCommandName) override {
        if (!guidCommandName) return E_POINTER;
        *guidCommandName = CLSID_ExtractHere;
        return S_OK;
    }

    IFACEMETHODIMP GetState(IShellItemArray* items, BOOL, EXPCMDSTATE* state) override {
        if (!state) return E_POINTER;
        *state = ECS_HIDDEN;

        std::filesystem::path archive;
        if (FAILED(GetSingleFilePath(items, archive))) return S_OK;
        if (!IsSupportedArchive(archive)) return S_OK;
        if (FindSevenZipGui().empty()) return S_OK;

        *state = ECS_ENABLED;
        return S_OK;
    }

    IFACEMETHODIMP Invoke(IShellItemArray* items, IBindCtx*) override {
        std::filesystem::path archive;
        HRESULT hr = GetSingleFilePath(items, archive);
        if (FAILED(hr) || !IsSupportedArchive(archive)) return E_INVALIDARG;

        const auto sevenZip = FindSevenZipGui();
        if (sevenZip.empty()) {
            MessageBoxW(nullptr,
                L"No se ha encontrado 7-Zip. Instálalo en su ruta habitual o registra su ruta en HKCU/HKLM\\SOFTWARE\\7-Zip.",
                L"7-Zip - Extraer aquí", MB_OK | MB_ICONERROR);
            return HRESULT_FROM_WIN32(ERROR_FILE_NOT_FOUND);
        }

        auto destination = archive.parent_path();
        std::wstring parameters = L"x -y -o" + Quote(destination.wstring()) + L" " + Quote(archive.wstring());

        HINSTANCE result = ShellExecuteW(nullptr, L"open", sevenZip.c_str(), parameters.c_str(),
            destination.empty() ? nullptr : destination.c_str(), SW_SHOWNORMAL);
        if (reinterpret_cast<INT_PTR>(result) <= 32) {
            return HRESULT_FROM_WIN32(static_cast<DWORD>(reinterpret_cast<INT_PTR>(result)));
        }
        return S_OK;
    }

    IFACEMETHODIMP GetFlags(EXPCMDFLAGS* flags) override {
        if (!flags) return E_POINTER;
        *flags = ECF_DEFAULT;
        return S_OK;
    }

    IFACEMETHODIMP EnumSubCommands(IEnumExplorerCommand** enumCommands) override {
        if (enumCommands) *enumCommands = nullptr;
        return E_NOTIMPL;
    }

private:
    std::atomic<ULONG> refCount_{1};
};

class CommandClassFactory final : public IClassFactory {
public:
    CommandClassFactory() { ++g_objectCount; }
    ~CommandClassFactory() { --g_objectCount; }

    IFACEMETHODIMP QueryInterface(REFIID riid, void** ppv) override {
        if (!ppv) return E_POINTER;
        *ppv = nullptr;
        if (riid == IID_IUnknown || riid == IID_IClassFactory) {
            *ppv = static_cast<IClassFactory*>(this);
            AddRef();
            return S_OK;
        }
        return E_NOINTERFACE;
    }

    IFACEMETHODIMP_(ULONG) AddRef() override { return ++refCount_; }

    IFACEMETHODIMP_(ULONG) Release() override {
        ULONG value = --refCount_;
        if (value == 0) delete this;
        return value;
    }

    IFACEMETHODIMP CreateInstance(IUnknown* outer, REFIID riid, void** ppv) override {
        if (outer) return CLASS_E_NOAGGREGATION;
        if (!ppv) return E_POINTER;

        auto* command = new (std::nothrow) ExtractHereCommand();
        if (!command) return E_OUTOFMEMORY;
        HRESULT hr = command->QueryInterface(riid, ppv);
        command->Release();
        return hr;
    }

    IFACEMETHODIMP LockServer(BOOL lock) override {
        if (lock) ++g_lockCount;
        else --g_lockCount;
        return S_OK;
    }

private:
    std::atomic<ULONG> refCount_{1};
};

} // namespace

extern "C" HRESULT __stdcall DllGetClassObject(REFCLSID clsid, REFIID riid, void** ppv) {
    if (clsid != CLSID_ExtractHere) return CLASS_E_CLASSNOTAVAILABLE;
    if (!ppv) return E_POINTER;

    auto* factory = new (std::nothrow) CommandClassFactory();
    if (!factory) return E_OUTOFMEMORY;
    HRESULT hr = factory->QueryInterface(riid, ppv);
    factory->Release();
    return hr;
}

extern "C" HRESULT __stdcall DllCanUnloadNow() {
    return (g_objectCount.load() == 0 && g_lockCount.load() == 0) ? S_OK : S_FALSE;
}

BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID) {
    return TRUE;
}
